#ifndef SIMDJSON_SRC_BASE_H
#define SIMDJSON_SRC_BASE_H

#include <simdjson/base.h>

#endif // SIMDJSON_SRC_BASE_H
